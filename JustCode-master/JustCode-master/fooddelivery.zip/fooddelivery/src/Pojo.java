
public class Pojo {
String Name, Address, Orderno;
int Bill;
long Phone;

public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getOrderno() {
	return Orderno;
}
public void setOrderno(String orderno) {
	Orderno = orderno;
}
public long getPhone() {
	return Phone;
}
public void setPhone(long phone) {
	Phone = phone;
}
public int getBill() {
	return Bill;
}
public void setBill(int bill) {
	Bill = bill;
}

}
