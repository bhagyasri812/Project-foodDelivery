

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Data
 */
@WebServlet("/Data")
public class Data extends HttpServlet {

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		HttpSession session= req.getSession(true);
		String a= (String) session.getAttribute("name");
		String b=(String) session.getAttribute("numb");
		int c=(int) session.getAttribute("total");
		String d=req.getParameter("addr");
		String e=req.getParameter("myField");
		long f=Long.parseLong(b);
		System.out.println(a+f+c+d+e);
		RequestDispatcher rd=req.getRequestDispatcher("/cart.jsp");

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection
					("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
		
		
				PreparedStatement st= conn.prepareStatement("insert into order1 values(?,?,?,?,?)");
				st.setString(1, a);
				st.setLong(2, f);
				st.setInt(3, c);
				st.setString(4, d);
				st.setString(5, e);
				st.execute();
				conn.commit();
				res.sendRedirect("Delivery.jsp");
				rd.forward(req, res);
				
				pw.close();
				
				
		}
			
			catch(Exception ae){
				ae.printStackTrace();
				
			}

	}

}
